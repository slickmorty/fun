package com.kara.webserver.datatypes;


public class BOM {


  private String bOMName;

  public BOM(String bOMName) {
    this.bOMName = bOMName;
  }




  public String getbOMName() {
    return bOMName;
  }

  public void setbOMName(String bOMName) {
    this.bOMName = bOMName;
  }


}
