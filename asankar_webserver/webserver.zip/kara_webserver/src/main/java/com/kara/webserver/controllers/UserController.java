package com.kara.webserver.controllers;


import com.kara.webserver.datatypes.User;
import com.kara.webserver.keyvaluepairs.AllowPermission;
import com.kara.webserver.repositories.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
class UserController {

  @Autowired
  private UserRepository userRepository;


  @GetMapping(path = "/auth/username={username}&password={passWord}")
  AllowPermission getUserAuth(@PathVariable int username, @PathVariable String passWord) {

    boolean flag = false;
    if (userRepository.findById(username).isPresent()) {
      User user = userRepository.findById(username).get();
      if (user.getPassWord().equals(passWord)) {
        flag = true;
      }
    }
    return AllowPermission.getInstance(flag);
  }

  @GetMapping(path = "/get/username={username}&password={passWord}")
  User getUserInfo(@PathVariable int username, @PathVariable String passWord){
    if(userRepository.findById(username).isPresent())
    {
      User user = userRepository.findById(username).get();
      if( user.getPassWord().equals(passWord)) {
        user.setPassWord(null);
        user.setUserName(-1);
        return user;
      }
      else return null;
    }
    else
      return null;
  }
}

