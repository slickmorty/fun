package com.kara.webserver.repositories;

import com.kara.webserver.datatypes.OP;

import org.springframework.data.repository.CrudRepository;

public interface OPRepository extends CrudRepository<OP, Integer> {
}
