package com.kara.webserver.datatypes;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Product {
  //Vars
  private @Id @GeneratedValue(strategy = GenerationType.IDENTITY) int id;
  private String productType;

//Constructor

  public Product(int id, String  productType) {
    this.id = id;
    this.productType = productType;
  }

  public Product() {
  }


  //Fucntions
  public String getProductType() {
    return productType;
  }

  public void setProductType(String productType) {
    this.productType = productType;
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

}
